  </div>
   </div> <!-- .content -->
    </div>


    <!-- <script src="<?php echo base_url(); ?>/vendors/chart.js/dist/Chart.bundle.min.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/dashboard.js"></script> -->
    <!-- <script src="<?php echo base_url(); ?>/assets/js/widgets.js"></script> -->
    

     <script src="<?php echo base_url(); ?>/vendors/datatables.net/js/jquery.dataTables.min.js"></script>
    <script src="<?php echo base_url(); ?>/vendors/datatables.net-bs4/js/dataTables.bootstrap4.min.js"></script>
    <script src="<?php echo base_url(); ?>/vendors/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
    <script src="<?php echo base_url(); ?>/vendors/datatables.net-buttons-bs4/js/buttons.bootstrap4.min.js"></script>
    <script src="<?php echo base_url(); ?>/vendors/jszip/dist/jszip.min.js"></script>
    <script src="<?php echo base_url(); ?>/vendors/pdfmake/build/pdfmake.min.js"></script>
    <script src="<?php echo base_url(); ?>/vendors/pdfmake/build/vfs_fonts.js"></script>
    <script src="<?php echo base_url(); ?>/vendors/datatables.net-buttons/js/buttons.html5.min.js"></script>
    <script src="<?php echo base_url(); ?>/vendors/datatables.net-buttons/js/buttons.print.min.js"></script>
    <script src="<?php echo base_url(); ?>/vendors/datatables.net-buttons/js/buttons.colVis.min.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/init-scripts/data-table/datatables-init.js"></script>

    
    <!-- <script src="<?php echo base_url(); ?>/vendors/sweetalert/sweetalert.min.js"></script> -->
    <script>
        /*(function($) {
            "use strict";

            jQuery('#vmap').vectorMap({
                map: 'world_en',
                backgroundColor: null,
                color: '#ffffff',
                hoverOpacity: 0.7,
                selectedColor: '#1de9b6',
                enableZoom: true,
                showTooltip: true,
                values: sample_data,
                scaleColors: ['#1de9b6', '#03a9f5'],
                normalizeFunction: 'polynomial'
            });
        })(jQuery);*/
    </script>

</body>

</html>